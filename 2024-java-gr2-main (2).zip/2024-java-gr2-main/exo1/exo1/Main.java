package exo1;

public class Main {
    public static void main(String[] args) {
        Voiture voiture = new Voiture();
        voiture.marque = "Toyota";
        voiture.modele = "Corolla";
        voiture.couleur = "Rouge";

        voiture.demarrer();
    }
}
