package gestion;

import java.util.ArrayList;

public class GestionEtudiant {
    private ArrayList<Etudiant> etudiants = new ArrayList<Etudiant>();

    public ArrayList<Etudiant> listE () {
        return this.etudiants;
    }
}
